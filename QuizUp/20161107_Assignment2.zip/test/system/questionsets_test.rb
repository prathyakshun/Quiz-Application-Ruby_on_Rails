require "application_system_test_case"

class QuestionsetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit questionsets_url
  #
  #   assert_selector "h1", text: "Questionset"
  # end
end
