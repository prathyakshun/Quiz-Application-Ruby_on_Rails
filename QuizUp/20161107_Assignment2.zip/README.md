RESTORING QUIZ GAME


USAGE:
	From the current directory,
	rails server
	Open Browser and go to 127.0.0.1:3000

APP DETAILS:

When a quiz is going on and the user logs out, and when the user comes back again to play the quiz he has an option of either resuming the quiz or starting it all over again.

* Login/Signup with Email, TWITTER account

* GAMEPLAY
	* Different types of Questions like MCQ, multi answer.
	* Each question is worth 10 Marks
	* Choose Quiz based on Genre and Subgenre
	* Can view leaderboard to view the leaderboard of all the players
	* Can view past quiz results

* USERS
	* User - Has the gameplay and ability to view past results, leaderboard
	* Admin - Can add, edit existing fields

* ADDON
	* Login with twitter account by adding one time email id and password
	* Get immediate correct answers after answering question

* POWERUPS
	* 50-50	: Reduce the number of options from 4 to 2
	* Multi-dip : Can choose more than 1 option, however for every wrong option -3

* SCORING
	* Each question is out of 10 marks
	* In mult-dip, if you get correct answer and few wrong answers, you get -3 for each wrong answer.  

* Google Analytics Charts
	At the end of the Quiz, get a performance report with a line graph and pie-chart for analysis

