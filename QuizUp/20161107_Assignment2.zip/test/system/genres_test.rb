require "application_system_test_case"

class GenresTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit genres_url
  #
  #   assert_selector "h1", text: "Genre"
  # end
end
