require "application_system_test_case"

class OptionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit options_url
  #
  #   assert_selector "h1", text: "Option"
  # end
end
